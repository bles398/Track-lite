
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

mock_tracking_db = {
    "ABC123": {
        "status": "In Transit",
        "location": "Distribution Center, Chicago, IL",
        "estimated_delivery": "2025-04-20"
    },
    "XYZ789": {
        "status": "Delivered",
        "location": "Front Door, Austin, TX",
        "estimated_delivery": "2025-04-15"
    }
}

@app.route('/track', methods=['GET'])
def track():
    tracking_number = request.args.get('tracking_number')
    if tracking_number in mock_tracking_db:
        return jsonify({
            "success": True,
            "data": mock_tracking_db[tracking_number]
        })
    else:
        return jsonify({
            "success": False,
            "error": "Tracking number not found."
        }), 404

if __name__ == '__main__':
    app.run(debug=True)
